package modul5.tugas.util;

public interface iMenu {
    void menu();
}
