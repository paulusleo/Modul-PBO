package modul5.tugas.books;

public class TextBook extends Book{
    public TextBook(String idBuku, String judul, int stok, String category, String author) {
        super(idBuku, judul, stok, category, author);
    }
}
